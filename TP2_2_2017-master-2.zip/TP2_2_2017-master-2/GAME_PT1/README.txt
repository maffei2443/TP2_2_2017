#### Instruções para execução do programa:
    1. ruby main.rb

#### Comandos do jogo:
    ESC   - Sai do game
    p     - Pausa/despausa o jogo
    o     - Ativa/desativa slowmotion
    Setas - Movimentam o personagem escolhido/movimenta seleção de personagem
    ENTER - Seleciona o personagem a ser usado durante o jogo na tela de    seleção de personagens
