require './desertfalcongui'

DesertFalconGUI.new.show
