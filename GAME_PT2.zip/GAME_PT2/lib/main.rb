require_relative './desertfalcongui'

DesertFalconGUI.new.show
