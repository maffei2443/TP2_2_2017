# Apenas um módulo para facilitar a chamada das bibliotecas a partir de main.rb.

require 'gosu'
require './box'
require './sprite'
require './gameObject'
require './falcon'
require './hiero'
require './rock'
require './desertfalcongui'