require './gameObject'


class Bullet < GameObject # Objeto assassino, mata inimigos e personagem

  def initialize(nameAuthor, x, y, zlist, falcOrNot)
    @movCoolDownTimer = 0 # Temporizador do movimento dos projeteis.
    @name = nameAuthor
    @sprite = Sprite.new("./img/" + nameAuthor + "/" + nameAuthor + "projectile.png") # Imagem do projetil encapsulada em um sprite.
    @hitbox = Hitbox.new(x,y,zlist,8,8) # Hitbox do projetil.
    @shooterFlag=falcOrNot
  end

  def draw() # Objeto renderiza seu sprite e uma sombra do seu sprite.
    @sprite.draw(@hitbox.x, @hitbox.y, @hitbox.zlist[0])
    Gosu::Image.new("./img/" + @name + "/" + @name + "projectile.png").draw(@hitbox.x, @hitbox.y, @hitbox.zlist[0] - 1, 1, 1, 0xff_464678, :default)
  end

  def update_frame() # A cada frame, caso o temporizador esteja zerado, o hiero deve se mover na diagonal para gerar impressão de movimento do personagem. O temporizador impede que ele se movimente rápido demais.
    if @movCoolDownTimer > 0
      @movCoolDownTimer -= 1
    end
    
    if(@movCoolDownTimer == 0)
      if (@shooterFlag == false)
        @hitbox.y += 3
        @hitbox.x -= 3
      else
        @hitbox.y -= 1
        @hitbox.x += 1
      end
      @movCoolDownTimer = 1

    end
  end

end