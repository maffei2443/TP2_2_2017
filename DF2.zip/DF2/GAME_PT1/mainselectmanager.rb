require 'gosu'


class MainSelectManager  # Gerenciador de opções de personagem, deve manter opção armazenada em estado, tratar entradas durante execução da seleção, mostrar na janela as opções de forma adequada

  def initialize(listofoptions, minheight, marginoffset, font)
    @menuSelect = false # Se o personagem foi selecionado.
    @selectopt = 1 # Opção de personagem.
    @playerOptionList = listofoptions # Opçoes de personagem para o jogador.
    @maxplayeroptions = @playerOptionList.size # Quantidade de opções de personagem.
    @kbSelectBuff = 0 # Para impedir o teclado de atualizar, a seleção de personagem mais rápido do que o usuário é capaz de notar.
    @font = font
    @selection = nil
    @@MINIMUM_HEIGHT = minheight
    @@MARGIN_OFFSET = marginoffset
    @@KEYBOARD_SELECTION_DELAY = 10
    @@BUTTON_SIZE = 48
  end

  attr_reader :menuSelect

  def select_opt()
    if (@kbSelectBuff > 0) # Reduz contador de espera do teclado, para aumentar o delay de resposta e o usuário conseguir reagir.
      @kbSelectBuff = @kbSelectBuff - 1
    end
    if (Gosu.button_down? Gosu::KB_RETURN) # Keyboard return(enter) é a seleção.
      @selection = @playerOptionList[@selectopt-1]
    else
      return nil
    end
  end

  def move_selection()
    if (Gosu.button_down? Gosu::KB_DOWN) and (@selectopt < @maxplayeroptions) and (@kbSelectBuff == 0) # Muda seleção para a direita.
      @selectopt = @selectopt + 1
      @kbSelectBuff = @@KEYBOARD_SELECTION_DELAY
    end

    if (Gosu.button_down? Gosu::KB_UP) and (@selectopt > 1) and (@kbSelectBuff == 0) # Muda seleção para a esquerda.
      @selectopt = @selectopt - 1
      @kbSelectBuff = @@KEYBOARD_SELECTION_DELAY
    end
  end

  def update_option # Enquanto não for selecionado um personagem, rodar a tela de seleção de personagems.
    self.move_selection
    self.select_opt
    if (@selection == "exit")
      exit()
    elsif (@selection == "play")
      @menuSelect = true
    end
  end

  def reset_selection
    @menuSelect = false # Se o personagem foi selecionado.
    @selectopt = 1 # Opção de personagem.
    @selection = nil
  end
  
  def draw # Printa opções na tela
    indexaux = 0
    @playerOptionList.each do # Para cada opção, verificar se ela foi escolhida pelo jogador. caso sim, printar ela com seleção
      |option|
      indexaux = indexaux + 1
      if (indexaux == @selectopt)
        Gosu::Image.new("./programicons/" + "selectorarrow.png").draw((@@MARGIN_OFFSET), @@MARGIN_OFFSET + ((@@BUTTON_SIZE) * (indexaux - 1)), @@MINIMUM_HEIGHT+1, 1, 1) # Caso seja a opção selecionada atualmente, mostre uma seta para deixar explícito para o usuário.
      end
      @font.draw(option, (@@MARGIN_OFFSET) + @@BUTTON_SIZE, @@MARGIN_OFFSET + ((@@BUTTON_SIZE) * (indexaux - 1)), @@MINIMUM_HEIGHT + 1, 1, 1, 0xff_ff00ff, :default)
    end
  end
end