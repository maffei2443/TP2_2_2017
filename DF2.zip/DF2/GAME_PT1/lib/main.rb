require './all'


DesertFalconGUI.new.show