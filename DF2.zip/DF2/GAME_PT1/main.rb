require './all'	# Chama arquivo responsável por incluir todas as bibliotecas que o programa irá usar (direta ou indiretamente).


DesertFalconGUI.new.show	# Cria interface do jogo e mostra na tela.