require 'gosu'


class TimeControlManager 

  def initialize(font, windowy, marginoff, hudlayer)
    @@WINDOW_SIZE_Y = windowy
    @font = font # Font para formatação de texto.
    @boopIterator = 0 # Iterador de boop, boop verifica se os frames estão passando ou não, uma alteração em boop indica que sim.
    @sysTime = (Time.now.to_f * 1000) # Primeira amostra de tempo usada no contador de fps.
    @FPScount = 0.0 # Inicia sem saber quantos frames tem.
    @paused = false
    @pausewait = 0
    @slowmoset = false
    @slowmo = false
    @slowsetwait = 0

    @@MARGIN_OFFSET = marginoff
    @@PAUSE_SLOWMO_TOGGLE_DELAY = 20
    @@HEADS_UP_DISPLAY_LAYER = hudlayer
    @@FPS_COUNTER_PERIOD = 60
  end

  attr_reader :paused, :slowmo

  def update_timing # Enquanto não for selecionado um personagem, rodar a tela de seleção de personagems. Após escolher um personagem, colocar esse personagem no jogo e rodar os frames do jogo.
    if ((Gosu.button_down? Gosu::KB_P) and (@pausewait == 0))# Pause.
      if (@paused == false)
        @paused = true
        @pausewait = @@PAUSE_SLOWMO_TOGGLE_DELAY
      else
        @paused = false
        @pausewait = @@PAUSE_SLOWMO_TOGGLE_DELAY
      end
    end
    if ((Gosu.button_down? Gosu::KB_O) and (@slowsetwait == 0))# Toggles slow motion.
      if (@slowmoset == false)
        @slowmoset = true
        @slowsetwait = @@PAUSE_SLOWMO_TOGGLE_DELAY
      else
        @slowmoset = false
        @slowmo = false
        @slowsetwait = @@PAUSE_SLOWMO_TOGGLE_DELAY
      end
    end
    if (@slowmoset == true)# Slowmotion frame controller.
      if (@slowmo == false)
        @slowmo = true
      else
        @slowmo = false
      end
    end
    if (@pausewait > 0)
      @pausewait -= 1
    end
    if (@slowsetwait > 0)
      @slowsetwait -= 1
    end
  end
  
  def draw # Caso não tenha sido selecionado um personagem, mostrar tela de seleção com botões para cada opção. Caso tenha sido selecionado um personagem, printar objetos do jogo nas suas respectivas posições.
    @font.draw("FPS := " + @FPScount.to_s, @@MARGIN_OFFSET, @@WINDOW_SIZE_Y - @@MARGIN_OFFSET, @@HEADS_UP_DISPLAY_LAYER + 1, 1, 1, 0xff_8000ff, :default) # Contador de fps convertido para string e disposto no fundo da tela
    
    @boopIterator = @boopIterator + 1
    
    if (@boopIterator > @@FPS_COUNTER_PERIOD/2)
	   @font.draw("BOOP!", 513, @@WINDOW_SIZE_Y - @@MARGIN_OFFSET, @@HEADS_UP_DISPLAY_LAYER + 1, 1, 1, 0xff_8000ff, :default) # Boop disposto na tela durante intervalo de 60 frames
    end
    if (@boopIterator  ==  @@FPS_COUNTER_PERIOD)
      @boopIterator = 0
      @FPScount = @@FPS_COUNTER_PERIOD / (((Time.now.to_f * 1000) - @sysTime) / 1000) # Quando boop terminar seu intervalo, é calculado a média de fps desse intervalo tempo que passou.
      @sysTime = (Time.now.to_f * 1000)
    end
  end
end