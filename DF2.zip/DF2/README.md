#### Instruções para execução do programa:
    1. ruby main.rb

#### Comandos do jogo:
    ESC   - Sai do game
    p     - Pausa/despausa o jogo
    Setas - Movimentam o personagem escolhido
    ENTER - Seleciona o personagem a ser usado durante o jogo na tela de    seleção de personagens
